READ ME
=======
-------

The B64.zip file is a zip archive file that BPS archives the 
the bps_b64_decode.txt files too. You cannot open some base64 decoded files 
on your website without causing the browser to detect some malware due to the 
php commands used in some base64 decoded hacking scripts. Even opening a txt
file can trigger the browser to see what it thinks is a threat even though
the bps_b64_decode.txt file is just a .txt file.

You should be able to download the zip file without having your browser
stop the download, but if you have software installed on your computer
that has Internet Protection and or Firewall protection then the download
may be blocked and your computer's Internet Protection or Firewall protection
will prevent you from downloading via a browser. If this happens you can 
can just download the B64.zip file via FTP or your Host Control Panel.